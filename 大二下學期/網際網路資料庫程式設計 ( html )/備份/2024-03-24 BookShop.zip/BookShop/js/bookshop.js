// 輪播圖版本 2
document.addEventListener('DOMContentLoaded', () => {
    const slides = document.querySelectorAll('.slider img');
    const navLinks = document.querySelectorAll('.slider-nav a');
    let currentIndex = 0;
    let autoPlayInterval = null;

    function showSlide(index) {
        let slideWidth = slides[index].clientWidth;
        document.querySelector('.slider').scrollLeft = slideWidth * index;
        updateNav(index);
    }

    function updateNav(index) {
        navLinks.forEach((link, i) => {
            link.style.opacity = i === index ? '1' : '0.75';
        });
    }

    function goToNextSlide() {
        currentIndex = (currentIndex + 1) % slides.length;
        showSlide(currentIndex);
    }

    navLinks.forEach((link) => {
        link.addEventListener('click', (event) => {
            const index = parseInt(event.currentTarget.getAttribute('data-index'), 10);
            currentIndex = index;
            showSlide(index);
        });
    });

    function startAutoPlay() {
        autoPlayInterval = setInterval(goToNextSlide, 3000);
    }

    function stopAutoPlay() {
        if (autoPlayInterval) {
            clearInterval(autoPlayInterval);
        }
    }

    // 初始化
    showSlide(currentIndex);
    startAutoPlay();

    // 滑鼠進入就不播放, 離開就播放
    const sliderWrapper = document.querySelector('.slider-wrapper');
    sliderWrapper.addEventListener('mouseenter', stopAutoPlay);
    sliderWrapper.addEventListener('mouseleave', startAutoPlay);
});

<!-- 沒有登入 -> 跳轉到登入頁面 -->
<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="zh-Hant-TW">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>個人資料與文章展示</title>
    <link href="bootstrap-5.3.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <?php include '.Style.php' ?>

</head>
<?php include '.Theme.php'; ?>


<body class=<?php echo $theme ?>>
    <!-- 標題橫條 + 切換按鈕 -->
    <?php include '.Header.php'; ?>
    <!-- 主要頁面內容開始 -->
    <main class="container mt-10vh">
        <div class="row">
            <!-- 個人資料區塊開始 -->
            <div class="col-md-4">
                <div class="profile-header">
                    <div class="profile-info d-flex flex-column align-items-center mb-5">
                        <div class="d-flex align-items-center">
                            <h2 class="h4">邱立宇</h2>
                            <button type="button" id="editProfile" class="bi bi-pencil-fill ms-1 btn-small-icon"
                                data-bs-toggle="modal" data-bs-target="#editProfileModal"></button>
                        </div>
                        <?php if (isset($_SESSION['message'])) {
                            echo $_SESSION['message'];
                            unset($_SESSION['message']);
                        } ?>
                    </div>
                </div>
                <div class="mb-3">
                    <textarea class="form-control" id="intro" rows="5" placeholder="暫無簡介" readonly
                        onclick="openModal()"></textarea>

                    <div class="modal fade" id="editIntroduceModal" tabindex="-1"
                        aria-labelledby="editIntroduceModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editIntroduceModalLabel">編輯簡介</h5>
                                </div>
                                <div class="modal-body">
                                    <form id="EditProfile" action=".EditProfile.php" method="post">
                                        <div class="mb-3">
                                            <label for="modalTextarea" class="form-label">簡介</label>
                                            <textarea class="form-control" id="modalTextarea" rows="5"></textarea>
                                        </div>
                                        <div class="d-flex justify-content-end">
                                            <button type="button" class="btn btn-secondary me-2"
                                                data-bs-dismiss="modal">取消</button>
                                            <button type="submit" id="EditConfirm" class="btn btn-primary">保存變更</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <script>
                        function openModal() {
                            // 獲取 textarea 內容並顯示在 modal 裡
                            var introText = document.getElementById('intro').value;
                            document.getElementById('modalTextarea').value = introText;

                            // 顯示 modal
                            var modal = new bootstrap.Modal(document.getElementById('editIntroduceModal'));
                            modal.show();

                            // 取消唯讀屬性
                            document.getElementById('modalTextarea').removeAttribute('readonly');
                        }
                    </script>
                    <div class="modal fade" id="editIntroduceModal" tabindex="-1"
                        aria-labelledby="editIntroduceModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editIntroduceModalLabel">編輯簡介</h5>
                                </div>
                                <div class="modal-body">
                                    <form id="EditProfile" action=".EditProfile.php" method="post">
                                        <div class="d-flex justify-content-end">
                                            <div>
                                                <button type="button" class="btn btn-secondary me-2"
                                                    data-bs-dismiss="modal">取消</button>
                                                <button type="submit" id="EditConfirm"
                                                    class="btn btn-primary">保存變更</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex">
                    <h3>動態<h3>
                </div>
                <div class="scroll-box">
                    <ul>
                        <li>剛剛發布的新的文章「漫步野花中的吹笛手」</li>
                        <li>一天前發布了新的文章「一瞬時刻」</li>
                        <li>兩天前發布了新的文章「我打江南走過」</li>
                        <li>七天前發布了新的文章「我欲乘風歸去」</li>
                    </ul>
                </div>
            </div>
            <!-- 個人資料編輯區 -->
            <div class="modal fade" id="editProfileModal" tabindex="-1" aria-labelledby="editProfileModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editProfileModalLabel">編輯個人資料</h5>
                        </div>
                        <div class="modal-body">
                            <form id="EditProfile" action=".EditProfile.php" method="post">
                                <div class="mb-3">
                                    <input type="text" class="form-control" id="username" name="username"
                                        placeholder="使用者名稱">
                                    <p class="text-red" id="username-err"></p>
                                </div>
                                <div class="mb-3">
                                    <input type="text" class="form-control" id="penName" name="penName"
                                        placeholder="使用者名稱">
                                    <p class="text-red" id="username-err"></p>
                                </div>
                                <div class="mb-3">
                                    <input type="password" class="form-control" id="newpassword" name="newpassword"
                                        placeholder="新密碼">
                                    <p class="text-red" id="newpassword-err"></p>
                                </div>
                                <div class="mb-3">
                                    <input type="email" class="form-control" id="email" name="email" placeholder="電子信箱">
                                    <p class="text-red" id="email-err"></p>
                                </div>
                                <div class="mb-3">
                                    <input type="tel" class="form-control" id="phone" name="phone" placeholder="手機號碼">
                                    <p class="text-red" id="phone-err"></p>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <div>
                                        <button type="button" class="btn btn-secondary me-2"
                                            data-bs-dismiss="modal">取消</button>
                                        <button type="submit" id="EditConfirm" class="btn btn-primary">保存變更</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <h3>文章撰寫</h3>
                <div class="row">
                    <div class="col-md-3">
                        <div data-bs-toggle='modal' data-bs-target='#editArticleModal'
                            class='edit text-decoration-none text-primary'>
                            <div class='card d-flex align-items-center justify-content-center'>
                                <i class="bi bi-file-earmark-plus"></i>
                                <h5 id="new-article" class='card-title text-Nmain clamp-lines mb-auto'>
                                    撰寫新文章
                                </h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div data-bs-toggle='modal' data-bs-target='#editArticleModal'
                            class='edit text-decoration-none text-primary'>
                            <div class='card mb-3 d-flex flex-column'>
                                <img src='<?php echo $product["image"]; ?>' class='card-img-top' alt='Product Image'>
                                <div class='card-body d-flex flex-column'>
                                    <h5 class='card-title text-Nmain clamp-lines mb-auto'>
                                        <?php echo htmlspecialchars($product["name"]); ?>
                                    </h5>
                                    <button class='btn cart' aria-label='編輯圖示'>編輯</button>
                                    <p class='card-text fw-bold text-orange mt-auto'><?php echo $product["price"]; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <h3 class="mb-3">星海同行</h3>
                <div class="row">
                    <div class="col-md-3">
                        <div data-bs-toggle='modal' data-bs-target='#editArticleModal'
                            class='edit text-decoration-none text-primary'>
                            <div class='card mb-3 d-flex flex-column'>
                                <img src='<?php echo $product["image"]; ?>' class='card-img-top' alt='Product Image'>
                                <div class='card-body d-flex flex-column'>
                                    <h5 class='card-title text-Nmain clamp-lines mb-auto'>
                                        <?php echo htmlspecialchars($product["name"]); ?>
                                    </h5>
                                    <button class='btn cart' aria-label='編輯圖示'>編輯</button>
                                    <p class='card-text fw-bold text-orange mt-auto'><?php echo $product["price"]; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- 文章編輯區 -->
            <div class="modal fade" id="editArticleModal" tabindex="-1" aria-labelledby="editArticleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editArticleModalLabel">編輯文章</h5>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="mb-3">
                                    <input type="text" class="form-control" id="articleTitle" placeholder="輸入標題">
                                </div>
                                <div class="mb-3">
                                    <textarea class="form-control " id="articleContent" rows="20"
                                        placeholder="輸入內容"></textarea>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <div>
                                        <button type="button" class="btn btn-secondary me-2"
                                            data-bs-dismiss="modal">取消</button>
                                        <button type="submit" class="btn btn-primary">保存變更</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- 主要頁面內容結束 -->
    <?php include '.Footer.php'; ?>
    <?php include '.Script.php' ?>

</body>

</html>
<!DOCTYPE html>
<html lang="zh-Hant-TW">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>書店Demo</title>
    <?php include '.Style.php' ?>
    <?php include '.LinkSql.php'; ?>
    <?php
    // 查詢商品資料
    $sql = "SELECT id, product_name, price, (SELECT image_path FROM product_images WHERE product_id = products.id LIMIT 1) AS image
            FROM products";
    $result = $link->query($sql);

    $products = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $price = floatval($row['price']);
            // 後兩位數都是 0 就只顯示整數
            $formatted_price = ($price == intval($price)) ? intval($price) : number_format($price, 2);

            $products[] = [
                "id" => $row['id'],
                "name" => $row['product_name'],
                "image" => $row['image'] ? $row['image'] : "https://via.placeholder.com/150",
                "price" => "$" . $formatted_price
            ];
        }
    } else {
        echo "<div class='mt-10vh'>沒有找到商品資料</div>";
        exit;
    }

    $link->close();
    ?>
</head>

<?php include '.Theme.php'; ?>
<!-- 標題橫條 + 切換按鈕 -->
<?php include '.Header.php'; ?>
<!-- 主要頁面內容開始 -->
<main>
    <!-- 廣告輪播區域開始 -->
    <section class="container ">
        <div class="slider-wrapper mt-10vh">
            <?php echo $message ?>
            <!-- 廣告圖片開始 -->
            <div class="slider">
                <img id="slide-1" src="images/book.png" alt="slider 1">
                <img id="slide-2"
                    src="https://plus.unsplash.com/premium_photo-1709311394823-8b0856db0bcc?q=80&w=1171&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                    alt="slider 2">
                <img id="slide-3"
                    src="https://images.unsplash.com/photo-1654859869130-fd0a2aa5539b?q=80&w=1228&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                    alt="slider 3">
            </div>
            <!-- 廣告圖片結束 -->
            <!-- 廣告輪播按鈕開始 (下方的三個點) -->
            <div class="slider-nav">
                <a data-index="0"></a>
                <a data-index="1"></a>
                <a data-index="2"></a>
            </div>
            <!-- 廣告輪播按鈕結束 -->
            <!-- 上一頁箭頭按鈕 -->
            <a class="prev-arrow fs-2"><i class='bx bx-chevron-left'></i></a>
            <!-- 下一頁箭頭按鈕 -->
            <div class="next-arrow fs-2"><i class='bx bx-chevron-right'></i></div>
        </div>
    </section>
    <!-- 廣告輪播區域結束 -->
    <!-- 商品購買區域開始 -->
    <section class="container mt-5">
        <!--分類按鈕開始 -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        全部
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <li><a class="dropdown-item" href="#">全部</a></li>
                        <li><a class="dropdown-item" href="#">回憶集錦</a></li>
                        <li><a class="dropdown-item" href="#">智識留心</a></li>
                        <li><a class="dropdown-item" href="#">詭譎暗影</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6">
                <input type="search" class="form-control" placeholder="搜尋商品...">
            </div>
        </div>
        <!-- 購物列表 -->
        <div class="row" id="shopping-list">
            <?php
            foreach ($products as $product) {
                echo "<div class='col-md-2' title={$product['name']}>
                    <a href='product.php?id={$product['id']}' class='card-link text-decoration-none text-primary'>
                        <div class='card mb-3'>
                            <img src='{$product['image']}' class='card-img-top' alt='Product Image'>
                            <div class='card-body'>
                                <h5 class='card-title text-Nmain text-truncate'>{$product['name']}</h5>
                                <p class='card-text fw-bold text-orange'>{$product['price']}</p>
                            </div>
                    </a>
                    <button class='btn cart' aria-label='購物車圖示'><i class='bi bi-cart'></i></button>
                </div>";
            }
            ?>
    </section>
    <!-- 商品購買區域結束 -->
</main>
<!-- 主要頁面內容開始 -->
<!-- footer 開始 -->
<?php include '.Footer.php'; ?>
<!-- footer結束 -->
</body>
<?php include '.Script.php' ?>

</html>
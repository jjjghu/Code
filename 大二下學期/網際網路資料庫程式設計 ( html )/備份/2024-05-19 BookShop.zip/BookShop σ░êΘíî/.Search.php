<?php
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$sql = "SELECT p.product_name, p.price, a.name AS author_name, p.write_date, c.name AS category_name, pc.content AS product_content 
        FROM products p
        JOIN authors a ON p.author_id = a.id
        JOIN categories c ON p.category_id = c.id
        JOIN product_contents pc ON p.id = pc.product_id
        WHERE p.id = $product_id";
$result = $link->query($sql);
if ($result->num_rows == 1) {
    while ($row = $result->fetch_assoc()) {
        $product_name = $row['product_name'];
        $price = $row['price'];
        $author_name = $row['author_name'];
        $write_date = $row['write_date'];
        $category_name = $row['category_name'];
        $product_content = nl2br($row['product_content']);
    }
} else {
    echo $result->num_rows == 0 ? "<div class='mt-10vh'>找不到商品資料</div>" : "<div class='mt-10vh'>找到多筆商品資料，請確認ID是否正確</div>";
    exit;
}

// 查詢商品圖片,
$sql_images = "SELECT image_path FROM product_images WHERE product_id = $product_id";
$result_images = $link->query($sql_images);
$images = [];
while ($row_image = $result_images->fetch_assoc()) {
    $images[] = $row_image['image_path'];
}
// 假設沒有圖片，使用預設圖片
if (empty($images)) {
    $images[] = 'images\book.png';
}
$link->close();
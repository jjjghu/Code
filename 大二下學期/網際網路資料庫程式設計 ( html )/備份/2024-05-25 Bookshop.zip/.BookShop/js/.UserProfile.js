document.addEventListener('DOMContentLoaded', function () {
    const textarea = document.getElementById('articleContent');
    function adjustTextareaHeight() {
        textarea.style.height = 'auto';
        const scrollHeight = textarea.scrollHeight;
        textarea.style.height = Math.min(scrollHeight, 600) + 'px';
        console.log("adjust!");
    }
    if (textarea) {
        textarea.addEventListener('input', adjustTextareaHeight);
    }
    else console.log("can't find articleContent");
});

// 新增驗證方法
// $.validator.addMethod("notEqualTo", function (value, element, param) {
//     return this.optional(element) || value != $(param).val();
// }, "新密碼不能與舊密碼相同");
// 從資料庫讀取很麻煩, 擱置
$(document).ready(function () {
    var validateProfile = function () {
        $("#EditProfile").validate({
            onfocusout: false,
            onkeyup: false,
            onclick: false,
            rules: {
                username: {
                    required: true,
                    minlength: 4,
                    maxlength: 16
                },
                penName:
                {
                    required: true,
                    maxlength: 16
                },
                newpassword: {
                    required: true,
                    minlength: 6,
                    maxlength: 16
                },
                email: {
                    required: true,
                    email: true
                },
                phone: {
                    required: true,
                    digits: true,
                    minlength: 10,
                    maxlength: 10
                }
            },
            messages: {
                username: {
                    required: "請輸入使用者名稱",
                    minlength: "使用者名稱至少要4個字元",
                    maxlength: "使用者名稱最多16個字元"
                },
                penName:
                {
                    required: "請輸入筆名",
                    maxlength: "筆名最多16個字元"
                },
                newpassword: {
                    required: "請輸入密碼",
                    minlength: "密碼至少要6個字元",
                    maxlength: "密碼最多16個字元"
                },
                email: {
                    required: "請輸入電子郵件",
                    email: "請輸入正確的電子郵件"
                },
                phone: {
                    required: "請輸入手機號碼",
                    digits: "手機號碼為數字",
                    minlength: "手機號碼為10個數字",
                    maxlength: "手機號碼為10個數字"
                }
            },
            errorPlacement: function (error, element) {
                var errorId = element.attr("id") + "-err"; // 根據元素ID獲取錯誤信息的ID
                $('#' + errorId).html(error.text()); // 顯示錯誤訊息到<p>當中
            }
        });
    };

    $('#EditConfirm').click(function (event) {
        event.preventDefault();
        validateProfile(); // 觸發表單驗證
        if ($("#EditProfile").valid()) { // 如果表單驗證通過，則提交表單
            // console.log("validate!");
            $("#EditProfile").submit();
        }
    });
});
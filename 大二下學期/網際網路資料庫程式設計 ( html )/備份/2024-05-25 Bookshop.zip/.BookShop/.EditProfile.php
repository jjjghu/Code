<?php
include '.LinkSql.php';
session_start(); // 確認已啟用會話
$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 接收表單內容

    $username = $_POST["username"];
    $newpassword = $_POST["newpassword"];
    $penName = $_POST["penName"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $hashed_password = password_hash($newpassword, PASSWORD_DEFAULT);

    $check_sql = "SELECT id, penName FROM author WHERE id != ? AND penName = ?;";
    $stmt = $link->prepare($check_sql);
    $stmt->bind_param("ss", $_SESSION['user_id'], $penName); // 問號取代變數
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $_SESSION['message'] = '<div class="text-red mt-2">筆名已被使用!</div>';
        header("Location: userProfile.php");
        exit;
    }

    // 找到使用者 id , 更新資料
    $check_sql = "SELECT * FROM author WHERE id = ?";
    $stmt = $link->prepare($check_sql);
    $stmt->bind_param("s", $_SESSION['user_id']);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $update_sql = "UPDATE author SET username = ?, password = ?, penName = ?, email = ?, phone = ? WHERE id = ?";
        $stmt = $link->prepare($update_sql);
        $stmt->bind_param("ssssss", $username, $hashed_password, $penName, $email, $phone, $_SESSION['user_id']);
        $stmt->execute();
        // 將 message 存放到SESSION
        $_SESSION['message'] = '<div class="text-success mt-2">更新成功!</div>';
        header("Location: userProfile.php");
        exit;
    }
} else {
}
$(document).ready(function () {
    $(".dropdown-menu a").click(function () {
        var selectedText = $(this).text();
        $("#dropdownMenuButton").text(selectedText);
    });
});
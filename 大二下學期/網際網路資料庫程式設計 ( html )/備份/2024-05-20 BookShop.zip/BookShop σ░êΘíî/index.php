<!DOCTYPE html>
<html lang="zh-Hant-TW">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>書店Demo</title>
    <?php include '.Style.php' ?>
    <?php include '.LinkSql.php'; ?>
    <?php
    // 查詢商品資料
    $sql = "SELECT id, product_name, price, (SELECT image_path FROM product_images WHERE product_id = products.id LIMIT 1) AS image
            FROM products";

    $search = isset($_GET['search']) ? $link->real_escape_string($_GET['search']) : '';
    $category = isset($_GET['category']) ? intval($_GET['category']) : 0;

    // 添加搜索條件
    if ($search) {
        $sql .= " WHERE product_name LIKE '%$search%'";
    }

    // 分類篩選條件
    if ($category) {
        $sql .= $search ? " AND" : " WHERE";
        $sql .= " id IN (SELECT product_id FROM product_category WHERE category_id = $category)";
    }

    $result = $link->query($sql);

    $products = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $price = floatval($row['price']);
            // 後兩位數都是 0 就只顯示整數
            $formatted_price = ($price == intval($price)) ? intval($price) : number_format($price, 2);

            $products[] = [
                "id" => $row['id'],
                "name" => $row['product_name'],
                "image" => $row['image'] ? $row['image'] : "https://via.placeholder.com/150",
                "price" => "$" . $formatted_price
            ];
        }
    } else {
        $message = "<div class='mt-10vh'>沒有找到商品資料</div>";
    }

    //------------------------------------------------------------------------------------------------
    // 商品分類DropDown動態產生
    $sql_categories = "SELECT id, name FROM categories";
    $result_categories = $link->query($sql_categories);

    $categories = [];
    if ($result_categories->num_rows > 0) {
        while ($row = $result_categories->fetch_assoc()) {
            $categories[] = [
                "id" => $row['id'],
                "name" => $row['name']
            ];
        }
    } else {
        $categories[] = [
            "id" => 0,
            "name" => "沒有找到分類資料"
        ];
    }
    $link->close();
    ?>
</head>

<?php include '.Theme.php'; ?>

<body class="' . $theme . '">
    <!-- 標題橫條 + 切換按鈕 -->
    <?php include '.Header.php'; ?>
    <!-- 主要頁面內容開始 -->
    <main>
        <section>
            <!-- 廣告輪播區域開始 -->
            <section class="container ">
                <div class="slider-wrapper mt-10vh">
                    <?php echo isset($message) ? $message : ''; ?>
                    <!-- 廣告圖片開始 -->
                    <div class="slider">
                        <img id="slide-1" src="images/book.png" alt="slider 1">
                        <img id="slide-2"
                            src="https://plus.unsplash.com/premium_photo-1709311394823-8b0856db0bcc?q=80&w=1171&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                            alt="slider 2">
                        <img id="slide-3"
                            src="https://images.unsplash.com/photo-1654859869130-fd0a2aa5539b?q=80&w=1228&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                            alt="slider 3">
                    </div>
                    <!-- 廣告圖片結束 -->
                    <!-- 廣告輪播按鈕開始 (下方的三個點) -->
                    <div class="slider-nav">
                        <a data-index="0"></a>
                        <a data-index="1"></a>
                        <a data-index="2"></a>
                    </div>
                    <!-- 廣告輪播按鈕結束 -->
                    <!-- 上一頁箭頭按鈕 -->
                    <a class="prev-arrow fs-2"><i class='bx bx-chevron-left'></i></a>
                    <!-- 下一頁箭頭按鈕 -->
                    <div class="next-arrow fs-2"><i class='bx bx-chevron-right'></i></div>
                </div>
            </section>
            <!-- 廣告輪播區域結束 -->
            <!-- 商品購買區域開始 -->
            <section class="container mt-5">
                <!--分類按鈕開始 -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                全部
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <?php foreach ($categories as $category): ?>
                                    <li><a class="dropdown-item"
                                            href="?category=<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <form action="" method="get">
                            <input type="search" name="search" class="form-control" placeholder="搜尋商品..."
                                value="<?php echo htmlspecialchars($search); ?>">
                        </form>
                    </div>
                </div>
                <!-- 購物列表 -->
                <div class="row" id="shopping-list">
                    <?php if (!empty($products)): ?>
                        <?php foreach ($products as $product): ?>
                            <div class='col-md-2' title='<?php echo htmlspecialchars($product["name"]); ?>'>
                                <a href='product.php?id=<?php echo $product["id"]; ?>'
                                    class='card-link text-decoration-none text-primary'>
                                    <div class='card mb-3 d-flex flex-column'>
                                        <img src='<?php echo $product["image"]; ?>' class='card-img-top' alt='Product Image'>
                                        <!-- 確保價格放在最低處, 就算文字過長也一樣 -->
                                        <div class='card-body d-flex flex-column'>
                                            <h5 class='card-title text-Nmain clamp-lines mb-auto'>
                                                <?php echo htmlspecialchars($product["name"]); ?>
                                            </h5>
                                            <p class='card-text fw-bold text-orange mt-auto'><?php echo $product["price"]; ?>
                                            </p>
                                        </div>
                                </a>
                                <button class='btn cart' aria-label='購物車圖示'><i class='bi bi-cart'></i></button>
                                <!-- div 和 a 必須要這樣放置, btn cart 才會正常運作 -->
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div>沒有找到商品資料</div>
                <?php endif; ?>
                </div>
            </section>
            <!-- 商品購買區域結束 -->
        </section>
    </main>
    <?php include '.Footer.php'; ?>
</body>
<?php include '.Script.php' ?>

</html>
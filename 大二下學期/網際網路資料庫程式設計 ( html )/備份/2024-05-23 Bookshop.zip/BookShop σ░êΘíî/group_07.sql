-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2024 年 05 月 22 日 08:52
-- 伺服器版本： 10.4.32-MariaDB
-- PHP 版本： 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `group_07`
--

-- --------------------------------------------------------

--
-- 資料表結構 `author`
--

CREATE TABLE `author` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `bio` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `author`
--

INSERT INTO `author` (`id`, `name`, `bio`) VALUES
(1, '瀟湘神', '本名羅傳樵，一九八二年生，畢業於東吳大學中文系、臺灣大學哲學所東方組碩士班，專長是儒學。性善論者。對人類學、民俗學、城市發展、腦科學等等有興趣。曾於臺大原住民族研究中心工作，現為臺北地方異聞工作室（網站、FB專頁）共同創辦人。現已出版《臺北城裡妖魔跋扈》、《帝國大學赤雨騷亂》、《金魅殺人魔術》、《都市傳說冒險團：謎樣的作家》、《殖民地之旅》、《魔神仔：被牽走的巨人》，曾參與《華麗島軼聞：鍵》、《筷：怪談競演奇物語》、《歡迎光臨錫爾帕夏車站》等聯合創作計畫。實境遊戲設計師，曾策劃〈金魅殺人魔術〉、〈西門町的四月笨蛋〉、〈城市邊陲的遁逃者〉等實境遊戲，並參與「說妖」的桌遊設計。'),
(2, '邱立宇', '就讀資訊工程學系的大二學生，\r\n目前正為了自己的未來發愁，就像隨處可見的大二學生一樣');

-- --------------------------------------------------------

--
-- 資料表結構 `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(0, '全部'),
(2, '回憶集錦'),
(3, '智識留心'),
(4, '詭譎暗影'),
(5, '虛構敘事'),
(6, '懸疑推理'),
(7, '現實寫實'),
(8, '科幻幻想'),
(9, '靈異神怪'),
(10, '愛情故事'),
(11, '歷史紀實'),
(12, '冒險奇遇'),
(13, '幽默搞笑'),
(14, '自傳回憶'),
(15, '社會觀察'),
(16, '哲理思考'),
(17, '散文隨筆'),
(18, '詩詞歌賦');

-- --------------------------------------------------------

--
-- 資料表結構 `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `write_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `products`
--

INSERT INTO `products` (`id`, `product_name`, `price`, `author_id`, `write_date`) VALUES
(1, '廢線彼端的人造神明', 349.00, 1, '2023-02-01'),
(2, '思明的日記', 0.00, 2, '2024-05-19'),
(3, 'AI產業的今日與未來 (上)', 300.00, 2, '2024-05-20');

-- --------------------------------------------------------

--
-- 資料表結構 `product_category`
--

CREATE TABLE `product_category` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `product_category`
--

INSERT INTO `product_category` (`product_id`, `category_id`) VALUES
(1, 5),
(1, 6),
(3, 3);

-- --------------------------------------------------------

--
-- 資料表結構 `product_contents`
--

CREATE TABLE `product_contents` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `content` text NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `product_contents`
--

INSERT INTO `product_contents` (`id`, `product_id`, `content`, `description`) VALUES
(1, 1, '台北的夜裡潛伏著黑暗____\r\n不，不是隱喻，是物質性、純粹無瑕的黑;是光子被拒斥，無緣進入之處。人來人往的地方，玲瓏剔透的路燈或許能像發燙的流星碎片，將光潑灑到人們溫熱的臉龐上，從城市高空俯瞰，街道像發光的血管汩汩而動，磅礡的熱力或許給人一種黑暗都被驅離的錯覺，但就算是最明亮的街道，也有燈照不進去的地方。\r\n\r\n', '【故事簡介】\r\n\r\n恭喜成為本公司最新產品「神」的試用者！\r\n這項產品具有改變世界的力量。\r\n請獻上祭品，召喚「祂」出現……\r\n\r\n雖然覺得是詐騙，但綽號「一號」的大學生還是不敵好奇心，召喚出自稱「偷竊之神」的迷你神！\r\n他四處嘗試偷竊之力時，收到宣稱「試用者身陷危險」的匿名信，想要商量對策。\r\n二十位試用者，只有七人現身討論，然而危機當前：有人在綁架神的試用者。\r\n\r\n幕後黑手指向「製造神的公司」，但眾人找不出提供產品又綁架的理由。\r\n檯面下，試用者各藏底牌──有人知道一切卻刻意隱瞞、\r\n有人遇到威脅無法說出實情、有人企圖反擊、沒現身的人躲在暗處謀畫。\r\n\r\n公司有祕密，但祕密引出更多的謎團。真相不只一個，\r\n和謎團等量的多重真相、試用者間不斷翻轉的心機鬥智，\r\n揭發出一起跨越國境、無比瘋狂的計畫！\r\n\r\n故事的終點──\r\n二十個稱作「神」的產品，「它」的真相是什麼？\r\n'),
(2, 2, '「失情」是一種病症，病如其名，會讓人漸漸失去感受情感的能力。\r\n\r\n我一直都不是一個樂觀開朗的人，但我一直很想成為那樣的人。\r\n\r\n童年時，家中時常出遊，山川、老街、夜市、廟宇。童年的記憶看似單薄，可一旦深挖，便會發現一處處湧泉。\r\n\r\n不知從何開始，出遊的次數銳減，\r\n學黌佔據我大多數的時間，我的作息開始不規律，考試只會讓我如釋重負，或是得到糟糕的心情。\r\n\r\n我發現自己對閱讀有興趣，讀的不是散文、詩歌，而是網路小說，再到後來，我發現自己搞錯了，我喜歡的是故事本身，跟表現形式無關。\r\n我開始記錄自己的生活，想把那些珍貴的回憶寫下來，我將它們一個個封存，以便我隨時翻看，讓這個世界的顏色，不要流逝的那麼快。\r\n...\r\n...\r\n日子大多像平靜的湖面，就這樣蹉跎光陰，日復一日。\r\n草木榮枯，四季輪轉，隨著年紀增長，時間移動的速度越來越快了，我開始時常會想，人死後會到哪裡去？\r\n\r\n死亡會從何時，用什麼樣的方式降臨？每思及此，心底便有股濃郁漆黑的恐懼蔓延，震顫著大腦。\r\n真好，至少我還感受的到恐懼。\r\n...\r\n...\r\n為了治好自己的病症，恢復從前鮮活的情感，\r\n我閱讀了大量典籍，順手醫治了很多人，不知不覺，我成了丹頂司最好的丹士。\r\n\r\n我試過很多方法，但無一例外都失敗了，有幾次還險些身死。\r\n\r\n我的情緒變動的越來越緩慢，像是要變成一攤死水，可心裡沒有一絲一毫的焦慮或是不安，興許是因為焦慮慣了，不安久了，自然也就無感了。\r\n\r\n有時我會想，既然生來注定，又為甚麼要去反抗呢? \r\n不是我的終究不會是我的，縱使掙扎的再劇烈，也只會落得相同的下場，外加變得更深的勒痕，長生種百年的壽命，此時卻顯得那樣的可怖，沒有了情緒，我會變成甚麼樣子?\r\n\r\n故事沒法在我的心底激起波瀾，那怕一絲，日記上的文字變得熟悉中帶點陌生，我記得當時自己寫下那些文字時眉飛色舞的神情，但我卻漸漸失去對情感的理解能力。\r\n\r\n我看著鏡中那張古井無波的臉，濃郁漆黑的恐懼蔓延，震顫著大腦。\r\n如今陪伴我的，還能讓我感受到「活著」的，只剩下恐懼。', '思名的日記，當中記錄了一種名叫「失情」的病緩慢發作的過程'),
(3, 3, '每過個十幾年，學界就會出現一個開天闢地的存在。\r\n當一個領域感覺已然山窮水盡，似乎就要觸及到極限時，人們總能發現一種全新看待問題的視角，找到另一個方向，從最早的專家系統到決策樹，向量機，再到近年的深度學習，Transformer。\r\n\r\n解決問題的方法大致可以分為兩種：分治法與端到端方法。\r\n分治法指的是將一個大問題切分成若干小問題，各自解決後再拼湊成完整的解決方案。\r\n例如，在開發自動駕駛系統時，分治法可能會將問題分解為車道保持、行人識別、障礙物避讓等小問題，然後各自解決這些小問題，最終組合成一個完整的系統。\r\n\r\n然而，分治法有其局限性。例如，自動駕駛AI需要在各種路況下做出最佳選擇，並且達到100%的準確度。使用分治法來實現這一點很難，因為面對的情況將近無限。解決大部分常見路況之後，想要進一步提升準確度，往往會變得非常困難且繁瑣。\r\n\r\n端到端方法則是給機器足夠多的數據，通過深度學習模型來自動學習如何處理各種情況。這種方法在處理複雜問題時往往能夠表現得更好，因為它能夠自動適應，學習從未見過的新情況。\r\n\r\n綜合以上，在面對複雜且多變的問題時，端到端方法可能更具優勢，這也是為甚麼自然語言處理會用端到端的方法去解決，因為語言的組合是無窮的。\r\n\r\n這樣看來，端到端算法很是神奇，給它資料，調些參數，模型就訓練好了，現在遇到的困境是甚麼呢? \r\n\r\n訓練人工智能，最終目的都是為了仿生。\r\n\r\n「人工智能產生超越人類的智慧，反過來支配了人類。」在這個時代已然不是一個新鮮的題材，而訓練出影視當中與常人無異的「機器人」，便是大多數人都想達成的里程碑。\r\n\r\n要做到這一點，首先要確保和它對話時不會中斷，而這也引出了一個問題，數據的傳輸。\r\n\r\n現在訓練一個語言模型，會花費大量時間在搬運數據上，和傳統的分治法不同，分治法解決小問題再拼起來，那些小問題互不相干，完全可以平行處理，在端到端的算法當中，每次都必須要將整塊丟入，得出一個結果，兩者都有搬運數據的問題，由於端到端本身的架構特性，這個問題被放大了。\r\n\r\n仿生仿的是人，答案就在我們的腦袋裡。\r\n\r\n人類的大腦不會花時間在搬運數據上，神經元同時扮演存儲和計算的功能，不需要搬運，大腦是存算一體的，更甚至連訓練都包含在內，時時更新。\r\n\r\n因此，未來的研究方向之一，便是如何實現存算一體的架構，徹底根治搬運數據的問題。\r\n\r\n假如做出了存算一體的架構，AI 便能夠大幅縮短溝通時的延遲 ( 以大語言模型為例)，現在 AI 能夠做到很多事情，但對各個專業領域的了解都比不上浸淫多年，對該領域了解深的人，如同一個基礎知識完備的大學生，缺乏對於單一領域的鑽研，但它是 AI，所以訓練的最終目標，自然就是一個全才，對於所有領域都深諳其道。\r\n\r\n怎麼壓縮信息? 是創造這個全才所需要的，必無可避的問題。\r\n\r\ninfinite context，是 google 最近發布的一篇論文，講述要怎麼將 AI 的 context 壓縮，騰出更多的空間給新的信息，隨著時間繼續向前走，將人類文明的所有知識壓縮進 AI 的大腦，並非不可能。\r\n\r\n人類積攢千年的知識塞進AI的「大腦」當中，它能夠做到自動駕駛、煮菜、提供心理諮詢，甚至教你微積分和英文，還能跟你打羽毛球，幫你寫文章，然後它的表現比你這個人類還要好，想像一下，一個存算一體的模型，它每分每秒都在自我進化，沒有人知道下一刻它會變成甚麼樣子，做出甚麼行動，這樣的模型，真的應該讓它存在嗎?\r\n\r\n當它成為了祂，人類該何去何從?\r\n...\r\n...\r\n撇開上面的問題，假如有這樣的一個模型，它會應用在甚麼方面呢?\r\n\r\n從小到大，你會遇到很多人，你的朋友、老師、同學、情人、親人、醫生... 等等，他們在你的人生中扮演不同的角色，你的同學同時是你的朋友，一個人可以扮演多個角色。\r\n\r\n現在有一個這樣全能的 AI，它可以扮演所有角色，那會變成甚麼樣的場景? 在遊戲當中每個 NPC 都是同一個模型去扮演的，實際上跟你交互的從頭到尾都是一個對象，搬到現實也是一樣的，那會是一個甚麼樣的光景?\r\n\r\n', '觀看 Youtube 影片之後的心得感想');

-- --------------------------------------------------------

--
-- 資料表結構 `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `image_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `image_path`) VALUES
(1, 1, 'images\\book1-1.png'),
(2, 1, 'images\\book1-2.png'),
(3, 1, 'images\\book1-3.png');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`author_id`);

--
-- 資料表索引 `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`product_id`,`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- 資料表索引 `product_contents`
--
ALTER TABLE `product_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- 資料表索引 `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `author`
--
ALTER TABLE `author`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `product_contents`
--
ALTER TABLE `product_contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `author` (`id`);

--
-- 資料表的限制式 `product_category`
--
ALTER TABLE `product_category`
  ADD CONSTRAINT `product_category_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- 資料表的限制式 `product_contents`
--
ALTER TABLE `product_contents`
  ADD CONSTRAINT `product_contents_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- 資料表的限制式 `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

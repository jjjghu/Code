// 全部的 cart-link 加入監聽事件 preventDefault
document.getElementsByClassName('card-link').forEach(function (element) {
    element.addEventListener('click', function (event) {
        event.preventDefault();
    });
});
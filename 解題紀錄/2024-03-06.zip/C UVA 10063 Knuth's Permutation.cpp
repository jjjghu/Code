// UVA 10063 - Knuth's Permutation
#include <bits/stdc++.h>
using namespace std;
const int mxN = 10;
char s[mxN + 1], ans[mxN + 1], len;
void dfs(int k)
{
    if (k == len) // 若建構完成
    { 
        ans[k] = '\0'; // 設定結尾
        cout << ans << endl; // 輸出完成的字串
    }
    else
    {
        for (int i = k; i >= 1; i--)
            ans[i] = ans[i - 1];
        for (int i = 0; i <= k; i++)
        {
            ans[i] = s[k];
            dfs(k + 1);
            ans[i] = ans[i + 1];
        }
    }
}

int main()
{
    bool flag = 1;
    while (cin >> s) // 和前一題差不多
    {
        if (flag == 0)
            cout << "\n";
        flag = 0;
        len = strlen(s);
        dfs(0); // 起點
    }
}

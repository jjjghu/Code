// CSES Creating Strings

// 解法1, 內建STL
// #include <iostream>
// #include <vector>
// #include <algorithm>
// using namespace std;
// int main(void)
// {
//     string s;
//     cin >> s;
//     sort(s.begin(), s.end());
//     vector<string> v;
//     do
//     {
//         v.push_back(s);
//     } while (next_permutation(s.begin(), s.end()));
//     cout << v.size() << endl;
//     for (string &str : v)
//     {
//         cout << str << endl;
//     }
// }

// 解法 2 遞迴
#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
using namespace std;
void backtrack(string &s, int level, set<string> &result)
{
    if (level == s.size()) // 終止條件
    {
        result.insert(s);
        return;
    }
    for (int i = level; i < s.size(); i++)
    {
        if (i != level && s[i] == s[level])
            continue; // 避免重複的排列,
        swap(s[level], s[i]);
        backtrack(s, level + 1, result);
        swap(s[level], s[i]); // 復原
    }
}
int main()
{
    string s;
    cin >> s;
    sort(s.begin(), s.end()); // sort 確保產生的組合有依照字典序大小

    set<string> p;      // 避免重複
    backtrack(s, 0, p); // 起點

    cout << p.size() << "\n"; // 輸出
    for (const string &perm : p)
        cout << perm << "\n";
    return 0;
}
// 167 - The Sultan's Successors
#include <iostream>
#include <algorithm>
#include <numeric>
#include <string.h>
#include <iomanip>
using namespace std;
int grid[8][8]; // 棋盤面貌
bool b[15];
void solve()
{
    cout << right << setw(5); // 輸出要求靠右 寬度5
    for (int i = 0; i < 8; ++i)
    {
        for (int j = 0; j < 8; ++j)
        {
            cin >> grid[i][j]; // 輸入棋盤
        }
    }
    int p[8], res = 0; // 排列方式, 輸出結果
    iota(p, p + 8, 0); // 將 p[0] ~ p[7] 數值變成 0 ~ 7, p[row] = p[col], 不會有重複, 因此不須判斷行列有沒有撞到
    do
    {
        bool ok = 1;                // 假設這個方法可以擺
        memset(b, 0, 15);           // 重置 b[15]
        for (int i = 0; i < 8; ++i) // 判斷主斜對角
            if (b[i + p[i]])        // row + col 為固定數值, 如果有人來過了, 表示皇后們發動戰爭了
                ok = 0;             // 不 ok, 戰火連天
            else                    // 沒人來過
                b[i + p[i]] = true; // 該皇后佔據這個對角線 (主)
        memset(b, 0, 15);           // 判斷負斜對角, 邏輯相同
        for (int i = 0; i < 8; ++i)
            if (b[i + 7 - p[i]]) // row - col 為固定數值 (-7 ~ 7), 但陣列index不可為負, 加入偏移量 7
                ok = 0;          // 戰爭!!!
            else
                b[i + 7 - p[i]] = true; // 西線無戰事
        int cur = 0;                    // 當前總數字和
        if (ok)                         // 如果沒有發生戰爭
        {
            for (int i = 0; i < 8; ++i)
            {
                cur += grid[i][p[i]]; // 計算總和
            }
            res = max(res, cur); // 更新最大值
        }
    } while (next_permutation(p, p + 8)); // 下一格行列擺放方式
    cout << res << endl;                  // 輸出答案
}
int main(void)
{
    int n;
    cin >> n;
    while (n--)
        solve();
}

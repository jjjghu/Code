#include <iostream>
#include <cmath>
using namespace std;
#define ll long long
int main(void)
{
    ll n;
    cin >> n;
    while (n--)
    {
        ll l, r;
        cin >> l >> r;
        if ((l + r) % 3) // 一次移掉3個硬幣, 必定為三的倍數
        {
            cout << "NO" << endl; // 不是三個倍數
        }
        else
        {
            if (max(l, r) > min(l, r) * 2) // 全部左邊取 2 右邊取 1, 如要取完, 左邊硬幣的數量必定 <= 右邊的硬幣數量*2, 反之亦然
                cout << "NO" << endl;
            else
                cout << "YES" << endl;
        }
    }
}

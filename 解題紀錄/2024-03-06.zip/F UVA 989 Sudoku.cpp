// UVA 989 Sudoku
// Fuck You Sudoku, Never again
#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;
int N;
int n;
int grid[9][9];

bool isSafe(int row, int col, int num) // 判斷有沒有辦法填入數字
{
    // 判斷行列
    for (int x = 0; x < N; x++)
    {
        if (grid[row][x] == num || grid[x][col] == num)
            return false; // 若已經被占據, 失敗
    }
    // 判斷九宮格
    int startRow = row - row % n, startCol = col - col % n;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (grid[i + startRow][j + startCol] == num)
                return false; // 相同原理
        }
    }
    // 過五關斬六將，過程曲折離奇，不願再提
    return true;
}

bool solve(int row, int col) // 解題
{
    // 如果碰到右邊緣,且為最後一行, 終止, 可以解開
    if (row == N - 1 && col == N)
        return true;
    if (col == N) // 到右邊緣 換下一行
    {
        ++row;
        col = 0;
    }

    if (grid[row][col] > 0)         // 若該格已經有數字
        return solve(row, col + 1); // 換下一個地點

    for (int num = 1; num <= N; num++)
    {
        if (isSafe(row, col, num)) // 判斷該位置可不可以填入數字
        {
            grid[row][col] = num;    // 將它填入
            if (solve(row, col + 1)) // 以這樣的狀態繼續解,看是不是答案
                return true;
        }
        grid[row][col] = 0; // 回朔
    }
    return false;
}

void printGrid() // 輸出答案
{
    for (int row = 0; row < N; row++)
    {
        for (int col = 0; col < N; col++)
        {
            if (col != 0)
                cout << " ";
            cout << grid[row][col]; // 空格不能放在最後, 很討厭。
        }
        cout << endl;
    }
    cout << endl;
}

int main(void)
{
    while (cin >> n)
    {
        memset(grid, 0, sizeof(grid));
        N = n * n; // 全域變數, 方便判斷
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < N; j++)
            {
                cin >> grid[i][j]; // 輸入 n*n 矩陣
            }
        }
        if (solve(0, 0)) // 從左上解到右下 如果有解開, 輸出解法
            printGrid();
        else
            cout << "NO SOLUTION\n"; // 沒有解開, GG
    }
}

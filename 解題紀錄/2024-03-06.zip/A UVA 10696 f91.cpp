// UVA 10690 f91
#include <iostream>
using namespace std;
int solve(int n)
{
    if (n <= 100) // 依照題意輸出即可
        return solve(solve(n + 11));
    else if (n >= 101)
        return n - 10;
}
int main(void)
{
    int n;
    while (cin >> n, n)
        cout << "f91(" << n << ") = " << solve(n) << endl;
}
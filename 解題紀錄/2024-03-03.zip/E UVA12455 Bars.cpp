#include <iostream>
#include <vector>
#include <cstring>
using namespace std;
// #define jjjghu
#ifdef jjjghu
#define debug(...)                             \
    do                                         \
    {                                          \
        fprintf(stderr, "(%s)", #__VA_ARGS__); \
        _DO(__VA_ARGS__);                      \
    } while (0)
template <typename T>
void _DO(T &&x) { cerr << x << endl; }
template <typename T, typename... I>
void _DO(T &&x, I &...tail)
{
    cerr << x << ", ";
    _DO(tail...);
}
#else
#define debug(...)
#endif
void fastIO()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
}
void solve() // 窮舉所有可能性
{
    int sticks[20];
    int target, p;
    cin >> target >> p;
    for (int i = 0; i < p; ++i)
        cin >> sticks[i];            // 獲取輸入
    for (int i = 0; i < 1 << p; ++i) // 將所有排列都試過一遍
    {
        int sum = 0;                // 當前排列的總和
        for (int j = 0; j < p; ++j) // 遍歷所有位數
        {
            if ((i >> j) & 1)     // 將 i (代表排列的數字)往右移動 j 格, 看看是不是 1
                sum += sticks[j]; // 是 1, 將長度加上去, 可在此提前判斷
        }
        if (sum == target) // 結果如果是目標答案
        {
            cout << "YES\n"; // 輸出
            return;          // 結束
        }
    }
    cout << "NO\n"; // 沒有排列滿足, 結束
    // Ex. 有三根棍子, 排列方法有 000 ~ 111 七種方法, 0 代表不取, 1 代表取
    // 010 = 不取第0 2根棍子, 取第1根棍子
}
int main(void)
{
    fastIO();
    int n;
    cin >> n;
    while (n--)
        solve();
}
#include <iostream>
using namespace std;
#define jjjghu
#ifdef jjjghu
#define debug(...)                             \
    do                                         \
    {                                          \
        fprintf(stderr, "(%s)", #__VA_ARGS__); \
        _DO(__VA_ARGS__);                      \
    } while (0)
template <typename T>
void _DO(T &&x) { cerr << x << endl; }
template <typename T, typename... I>
void _DO(T &&x, I &...tail)
{
    cerr << x << ", ";
    _DO(tail...);
}
#else
#define debug(...)
#endif
void fastIO()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
}
int main(void)
{
    fastIO();
    int t;
    cin >> t;
    for (int c = 1; c <= t; ++c)
    {
        int a, b;
        cin >> a >> b;
        long long ans = 0; // 輸入如果是兩個int 接近極限的數字, 相加會爆炸
        if (!(a & 1))      // 如果前面的數字是偶數, 往前走一步, 方便計算
            ++a;
        for (int i = a; i <= b; i += 2) // 從起點加到終點, 可用公式
            ans += i;
        cout << "Case " << c << ": " << ans << "\n";
    }
}
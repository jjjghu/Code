#include <iostream>
#include <string>
#include <vector>
using namespace std;
// #define jjjghu
#ifdef jjjghu
#define debug(...)                             \
    do                                         \
    {                                          \
        fprintf(stderr, "(%s)", #__VA_ARGS__); \
        _DO(__VA_ARGS__);                      \
    } while (0)
template <typename T>
void _DO(T &&x) { cerr << x << endl; }
template <typename T, typename... I>
void _DO(T &&x, I &...tail)
{
    cerr << x << ", ";
    _DO(tail...);
}
#else
#define debug(...)
#endif
void fastIO()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
}
const int mxN = 51;
bool list[mxN][mxN];
int dx[] = {0, 1, 0, -1};
int dy[] = {1, 0, -1, 0};
string dir = "NESW";
int main()
{
    fastIO();
    int xMax, yMax;
    cin >> xMax >> yMax; // 輸入邊界

    int x, y;       // 座標
    char orin;      // 當前面向
    string command; // 指令

    while (cin >> x >> y >> orin >> command)
    {
        int dirIndex = dir.find(orin); // 獲取index;
        bool lost = false;             // 預設活著

        for (char &cmd : command)
        {
            if (cmd == 'R') // 轉向
                dirIndex = (dirIndex + 1) % 4;
            else if (cmd == 'L')
                dirIndex = (dirIndex + 3) % 4;
            else if (cmd == 'F') // 前進
            {
                int newX = x + dx[dirIndex];
                int newY = y + dy[dirIndex];
                // 判斷邊界條件
                if (newX >= 0 && newX <= xMax && newY >= 0 && newY <= yMax)
                {
                    x = newX;
                    y = newY;
                }
                else if (!list[x][y]) // 前往死亡且這裡沒死過人
                {
                    list[x][y] = true; // 標記死亡
                    lost = true;       // 車子爛掉了
                    break;             // 跳出迴圈
                }
            }
        }
        cout << x << " " << y << " " << dir[dirIndex]; // 輸出最後位置
        if (lost)                                      // 如果車子爛掉
            cout << " LOST";                           // 輸出gg
        cout << endl;
    }
}

#include <iostream>
#include <vector>
using namespace std;
// #define jjjghu
#ifdef jjjghu
#define debug(...)                             \
    do                                         \
    {                                          \
        fprintf(stderr, "(%s)", #__VA_ARGS__); \
        _DO(__VA_ARGS__);                      \
    } while (0)
template <typename T>
void _DO(T &&x) { cerr << x << endl; }
template <typename T, typename... I>
void _DO(T &&x, I &...tail)
{
    cerr << x << ", ";
    _DO(tail...);
}
#else
#define debug(...)
#endif
void fastIO()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
}
void solve() // bubble sort, 看交換了幾次
{
    int n;
    cin >> n;
    vector<int> list(n);
    for (int &i : list)
        cin >> i; // 獲取輸入
    int res = 0;
    for (int i = 0; i < n - 1; ++i) // 後面 n-1 定下來, 最後一項就定下來了
    {
        for (int j = 1; j < n - i; ++j) // 後面 i 項已經排好, 不需要考慮
        {
            if (list[j - 1] > list[j]) // 將大的數字往上放
            {
                ++res;                      // 更新答案
                swap(list[j - 1], list[j]); // 交換數字
            }
        }
    }
    cout << "Optimal train swapping takes " << res << " swaps.\n";
}
int main(void)
{
    fastIO();
    int n;
    cin >> n;
    while (n--)
        solve();
    return 0;
}
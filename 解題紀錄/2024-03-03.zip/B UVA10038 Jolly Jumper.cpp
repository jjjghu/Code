#include <iostream>
#include <vector>
using namespace std;
// #define jjjghu
#ifdef jjjghu
#define debug(...)                             \
    do                                         \
    {                                          \
        fprintf(stderr, "(%s)", #__VA_ARGS__); \
        _DO(__VA_ARGS__);                      \
    } while (0)
template <typename T>
void _DO(T &&x) { cerr << x << endl; }
template <typename T, typename... I>
void _DO(T &&x, I &...tail)
{
    cerr << x << ", ";
    _DO(tail...);
}
#else
#define debug(...)
#endif
void fastIO()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
}
void solve(int n) // 跳跳跳
{
    if (n < 1) // 只有一個數字, 就不會有任何兩數中間值
    {
        cout << "Not Jolly\n";
        return;
    }

    int enter, prev;
    vector<bool> list(n, false); // 數字的差從 1 ~ n-1, 紀錄有無出現
    for (int i = 0; i < n; ++i)
    {
        if (i == 0) // 輸入第一個數字
        {
            cin >> prev;
            continue;
        }
        cin >> enter;
        int d = abs(enter - prev); // 數字的差, 取正
        if (d < n && d > 0)        // 確保不會超出陣列範圍 (無用數字)
            list[d - 1] = true;    // 更新陣列, -1 看個人
        prev = enter;              // 更新前項
    }
    for (int i = 0; i < n - 1; ++i) // 由於 -1, 檢查範圍需要 < n-1
    {
        if (list[i] == false)
        {
            cout << "Not jolly\n"; // 有數字差值沒出現, 是 jolly 不是 Jolly (fxxk)
            return;
        }
    }
    cout << "Jolly\n";
}
int main(void)
{
    fastIO();
    int n;
    while (cin >> n)
    {
        solve(n);
    }
    return 0;
}
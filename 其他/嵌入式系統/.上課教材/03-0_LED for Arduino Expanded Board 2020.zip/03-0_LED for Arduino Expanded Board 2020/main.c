#include "profile.h"

#define Init_Routine()		Init_GLED()

int main( void ){
	//Configure PD7 as output to drive green LED
	Init_Routine();						
	for(;;){
		GLED_ON();			//Turn on GLED
		Delay_10ms(25);		//Delay for 250 ms
		GLED_OFF();			//Turn off GLED
		Delay_10ms(10);		//Delay for 100 ms
	}
	return 0;
}
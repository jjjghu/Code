#ifndef _PROFILE_H
#define _PROFILE_H

#include <ioavr.h>
#include <stdint.h>
#include <intrinsics.h>

//the default clock frequency of an Arduino UNO is 16 MHz
#define F_CPU 			16000000UL		
#define Delay_1us(us) __delay_cycles((F_CPU / 1000000UL) * (us))
#define Delay_1ms(ms) __delay_cycles((F_CPU / 1000UL) * (ms))
#define Delay_10ms(count) Delay_1ms(count * 10)
//Define PD7 as GLED
#define GLED			7				
#define GLED_DIR		DDRD
#define GLED_PORT		PORTD
#define GLED_ON()		GLED_PORT &= ~(1<<GLED)
#define GLED_OFF()		GLED_PORT |= (1<<GLED)
#define Init_GLED()		GLED_OFF();\
						GLED_DIR |= (1<<GLED)
#endif